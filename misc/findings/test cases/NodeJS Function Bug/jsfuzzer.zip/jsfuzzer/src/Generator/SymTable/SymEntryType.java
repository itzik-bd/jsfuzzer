package Generator.SymTable;

public enum SymEntryType
{
	FUNC,
	VAR;
}