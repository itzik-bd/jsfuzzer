package Generator.Params;

public class funcDefParams extends createParams 
{
	private int _paramsNumber;

	public funcDefParams()
	{ 
		
	}

	public void setParamNumber(int paramNum)
	{
		_paramsNumber = paramNum; 
	}
	
	public int getParamNumber()
	{
		return (_paramsNumber);
	}
}
