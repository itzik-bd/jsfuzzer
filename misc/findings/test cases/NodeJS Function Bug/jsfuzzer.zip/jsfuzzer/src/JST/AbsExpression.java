package JST;

public abstract class AbsExpression extends AbsStatement
{

}
