package JST.Interfaces;

public interface ProgramUnit extends JSTObject
{

}