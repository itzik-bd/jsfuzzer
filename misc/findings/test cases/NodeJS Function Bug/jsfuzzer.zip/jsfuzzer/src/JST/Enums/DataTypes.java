package JST.Enums;

public enum DataTypes
{
	UNDEFINED,
	STRING,
	NUMBER,
	BOOLEAN,
	ARRAY,
	OBJECT,
	FUNCTION;
}