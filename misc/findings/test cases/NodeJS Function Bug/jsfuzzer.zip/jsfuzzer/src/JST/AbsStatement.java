package JST;

import JST.Interfaces.ProgramUnit;

public abstract class AbsStatement extends JSTNode implements ProgramUnit
{

}