package JST.Interfaces;

public interface Caseable extends JSTObject {

}
