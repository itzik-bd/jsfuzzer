package JST.Interfaces;

public interface Assignable extends JSTObject
{

}