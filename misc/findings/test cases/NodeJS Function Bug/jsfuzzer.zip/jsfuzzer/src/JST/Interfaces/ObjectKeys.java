package JST.Interfaces;

public interface ObjectKeys extends JSTObject {}